set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_ST;
create  index I_YWGY_STZL_ST on T_YWGY_STZL (C_BH_ST);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_ZHXGSJ;
create  index I_YWGY_STZL_ZHXGSJ on T_YWGY_STZL (DT_ZHXGSJ);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_SSDW;
create  index I_YWGY_STZL_SSDW on T_YWGY_STZL (C_BH_SSDW);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_CJR;
create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_ZHXGR;
create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_JLZL_JL;
create  index I_YWGY_JLZL_JL on T_YWGY_JLZL (C_BH_JL);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_JLZL_ZHGXSJ;
create  index I_YWGY_JLZL_ZHGXSJ on T_YWGY_JLZL (DT_ZHXGSJ);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_JLZL_BM;
create  index I_YWGY_JLZL_BM on T_YWGY_JLZL (C_BM);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_JLZL_SSDW;
create  index I_YWGY_JLZL_SSDW on T_YWGY_JLZL (C_BH_SSDW);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_JLZL_ST;
create  index I_YWGY_JLZL_ST on T_YWGY_JLZL (C_BH_ST);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_CJR;
create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR);
commit;

set search_path to DB_YWST;
commit;

drop index if exists I_YWGY_STZL_ZHXGR;
create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR);
commit;

