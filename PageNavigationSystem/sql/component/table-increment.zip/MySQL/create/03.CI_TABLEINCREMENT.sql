use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_ST');

create  index I_YWGY_STZL_ST on T_YWGY_STZL (C_BH_ST);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_ZHXGSJ');

create  index I_YWGY_STZL_ZHXGSJ on T_YWGY_STZL (DT_ZHXGSJ);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_SSDW');

create  index I_YWGY_STZL_SSDW on T_YWGY_STZL (C_BH_SSDW);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_CJR');

create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_ZHXGR');

create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_JLZL','I_YWGY_JLZL_JL');

create  index I_YWGY_JLZL_JL on T_YWGY_JLZL (C_BH_JL);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_JLZL','I_YWGY_JLZL_ZHGXSJ');

create  index I_YWGY_JLZL_ZHGXSJ on T_YWGY_JLZL (DT_ZHXGSJ);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_JLZL','I_YWGY_JLZL_BM');

create  index I_YWGY_JLZL_BM on T_YWGY_JLZL (C_BM);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_JLZL','I_YWGY_JLZL_SSDW');

create  index I_YWGY_JLZL_SSDW on T_YWGY_JLZL (C_BH_SSDW);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_JLZL','I_YWGY_JLZL_ST');

create  index I_YWGY_JLZL_ST on T_YWGY_JLZL (C_BH_ST);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_CJR');

create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_YWGY_STZL_ZHXGR');

create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_STZL','I_PK_T_YWGY_STZL');

create  index I_PK_T_YWGY_STZL on T_YWGY_STZL (C_BH);


use DB_YWST;

call pr_Drop_index_if_exists('T_YWGY_JLZL','I_PK_T_YWGY_JLZL');

create  index I_PK_T_YWGY_JLZL on T_YWGY_JLZL (C_BH);


