-- auto create by SMD

use DB_YWST;

-- 实体增量表

drop table if exists T_YWGY_STZL;

create table DB_YWST.T_YWGY_STZL
(
    C_BH                 char(32)                             NOT NULL     comment '主键',
    C_YWLX               varchar(300)                         NULL         comment '业务类型',
    C_BH_ST              char(32)                             NULL         comment '实体主键',
    N_ZHXGFS             int                                  NULL         comment '最后修改方式',
    DT_CJSJ              datetime                             NULL         comment '创建时间',
    DT_ZHXGSJ            datetime                             NULL         comment '最后修改时间',
    DT_SCSJ              datetime                             NULL         comment '删除时间',
    C_BH_CJR             varchar(300)                         NULL         comment '创建人主键',
    C_BH_ZHXGR           varchar(300)                         NULL         comment '最后修改人主键',
    C_BH_SSDW            varchar(300)                         NULL         comment '所属单位主键'
) comment = '实体增量表' ;


use DB_YWST;

-- 数据删除记录

drop table if exists T_YWGY_JLZL;

create table DB_YWST.T_YWGY_JLZL
(
    C_BH                 char(32)                             NOT NULL     comment '主键',
    C_BM                 varchar(300)                         NULL         comment '表名',
    C_BH_JL              char(32)                             NULL         comment '记录主键',
    N_ZHXGFS             int                                  NULL         comment '最后修改方式',
    DT_CJSJ              datetime                             NULL         comment '创建时间',
    DT_ZHXGSJ            datetime                             NULL         comment '最后修改时间',
    DT_SCSJ              datetime                             NULL         comment '删除时间',
    C_BH_CJR             varchar(300)                         NULL         comment '创建人主键',
    C_BH_ZHXGR           varchar(300)                         NULL         comment '最后修改人主键',
    C_BH_SSDW            varchar(300)                         NULL         comment '所属单位主键',
    C_BH_ST              char(32)                             NULL         comment '实体主键'
) comment = '数据删除记录' ;


