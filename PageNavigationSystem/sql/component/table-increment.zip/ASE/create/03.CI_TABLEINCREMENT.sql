use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_ST' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_ST
go

create  index I_YWGY_STZL_ST on T_YWGY_STZL (C_BH_ST)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_ZHXGSJ' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_ZHXGSJ
go

create  index I_YWGY_STZL_ZHXGSJ on T_YWGY_STZL (DT_ZHXGSJ)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_SSDW' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_SSDW
go

create  index I_YWGY_STZL_SSDW on T_YWGY_STZL (C_BH_SSDW)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_CJR' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_CJR
go

create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_ZHXGR' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_ZHXGR
go

create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_JLZL_JL' and id = object_id('T_YWGY_JLZL'))
drop index T_YWGY_JLZL.I_YWGY_JLZL_JL
go

create  index I_YWGY_JLZL_JL on T_YWGY_JLZL (C_BH_JL)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_JLZL_ZHGXSJ' and id = object_id('T_YWGY_JLZL'))
drop index T_YWGY_JLZL.I_YWGY_JLZL_ZHGXSJ
go

create  index I_YWGY_JLZL_ZHGXSJ on T_YWGY_JLZL (DT_ZHXGSJ)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_JLZL_BM' and id = object_id('T_YWGY_JLZL'))
drop index T_YWGY_JLZL.I_YWGY_JLZL_BM
go

create  index I_YWGY_JLZL_BM on T_YWGY_JLZL (C_BM)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_JLZL_SSDW' and id = object_id('T_YWGY_JLZL'))
drop index T_YWGY_JLZL.I_YWGY_JLZL_SSDW
go

create  index I_YWGY_JLZL_SSDW on T_YWGY_JLZL (C_BH_SSDW)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_JLZL_ST' and id = object_id('T_YWGY_JLZL'))
drop index T_YWGY_JLZL.I_YWGY_JLZL_ST
go

create  index I_YWGY_JLZL_ST on T_YWGY_JLZL (C_BH_ST)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_CJR' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_CJR
go

create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR)
go

use DB_YWST
go

if exists( select 1 from sysindexes
            where name= 'I_YWGY_STZL_ZHXGR' and id = object_id('T_YWGY_STZL'))
drop index T_YWGY_STZL.I_YWGY_STZL_ZHXGR
go

create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR)
go

