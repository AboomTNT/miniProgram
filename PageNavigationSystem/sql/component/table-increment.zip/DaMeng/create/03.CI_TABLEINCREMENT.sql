set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_ST' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_ST';
 end if;
end;
/
  create  index I_YWGY_STZL_ST on DB_YWST.T_YWGY_STZL (C_BH_ST);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_ZHXGSJ' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_ZHXGSJ';
 end if;
end;
/
  create  index I_YWGY_STZL_ZHXGSJ on DB_YWST.T_YWGY_STZL (DT_ZHXGSJ);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_SSDW' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_SSDW';
 end if;
end;
/
  create  index I_YWGY_STZL_SSDW on DB_YWST.T_YWGY_STZL (C_BH_SSDW);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_CJR' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_CJR';
 end if;
end;
/
  create  index I_YWGY_STZL_CJR on DB_YWST.T_YWGY_STZL (C_BH_CJR);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_ZHXGR' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_ZHXGR';
 end if;
end;
/
  create  index I_YWGY_STZL_ZHXGR on DB_YWST.T_YWGY_STZL (C_BH_ZHXGR);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_JLZL_JL' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_JLZL_JL';
 end if;
end;
/
  create  index I_YWGY_JLZL_JL on DB_YWST.T_YWGY_JLZL (C_BH_JL);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_JLZL_ZHGXSJ' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_JLZL_ZHGXSJ';
 end if;
end;
/
  create  index I_YWGY_JLZL_ZHGXSJ on DB_YWST.T_YWGY_JLZL (DT_ZHXGSJ);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_JLZL_BM' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_JLZL_BM';
 end if;
end;
/
  create  index I_YWGY_JLZL_BM on DB_YWST.T_YWGY_JLZL (C_BM);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_JLZL_SSDW' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_JLZL_SSDW';
 end if;
end;
/
  create  index I_YWGY_JLZL_SSDW on DB_YWST.T_YWGY_JLZL (C_BH_SSDW);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_JLZL_ST' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_JLZL_ST';
 end if;
end;
/
  create  index I_YWGY_JLZL_ST on DB_YWST.T_YWGY_JLZL (C_BH_ST);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_CJR' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_CJR';
 end if;
end;
/
  create  index I_YWGY_STZL_CJR on DB_YWST.T_YWGY_STZL (C_BH_CJR);

commit;

set char_code UTF8
set auto on
set define off

 begin 
 if exists( select 1 from sysobjects
              where subtype$='INDEX' and name= 'I_YWGY_STZL_ZHXGR' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
 EXECUTE immediate  'drop index DB_YWST.I_YWGY_STZL_ZHXGR';
 end if;
end;
/
  create  index I_YWGY_STZL_ZHXGR on DB_YWST.T_YWGY_STZL (C_BH_ZHXGR);

commit;

