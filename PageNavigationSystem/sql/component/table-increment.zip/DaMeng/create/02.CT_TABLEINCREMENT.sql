-- auto create by SMD

set char_code UTF8
set auto on
set define off

-------------------------
-- 实体增量表
-------------------------

 begin 
 if exists( select 1 from sysobjects
              where subtype$='UTAB' and name= 'T_YWGY_STZL' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
  EXECUTE immediate 'drop table DB_YWST.T_YWGY_STZL'; 
 end if; 
 end;
/
 commit;

create table DB_YWST.T_YWGY_STZL
(
    C_BH                  char(32)                             NOT NULL,    -- 主键
    C_YWLX                varchar(300)                         NULL,        -- 业务类型
    C_BH_ST               char(32)                             NULL,        -- 实体主键
    N_ZHXGFS              integer                              NULL,        -- 最后修改方式
    DT_CJSJ               datetime                             NULL,        -- 创建时间
    DT_ZHXGSJ             datetime                             NULL,        -- 最后修改时间
    DT_SCSJ               datetime                             NULL,        -- 删除时间
    C_BH_CJR              varchar(300)                         NULL,        -- 创建人主键
    C_BH_ZHXGR            varchar(300)                         NULL,        -- 最后修改人主键
    C_BH_SSDW             varchar(300)                         NULL,        -- 所属单位主键
constraint PK_YWGY_STZL primary key( C_BH )
);

 commit; 

set char_code UTF8
set auto on
set define off

-------------------------
-- 数据删除记录
-------------------------

 begin 
 if exists( select 1 from sysobjects
              where subtype$='UTAB' and name= 'T_YWGY_JLZL' and schid in (select id from SYSOBJECTS where NAME = 'DB_YWST')) then
  EXECUTE immediate 'drop table DB_YWST.T_YWGY_JLZL'; 
 end if; 
 end;
/
 commit;

create table DB_YWST.T_YWGY_JLZL
(
    C_BH                  char(32)                             NOT NULL,    -- 主键
    C_BM                  varchar(300)                         NULL,        -- 表名
    C_BH_JL               char(32)                             NULL,        -- 记录主键
    N_ZHXGFS              integer                              NULL,        -- 最后修改方式
    DT_CJSJ               datetime                             NULL,        -- 创建时间
    DT_ZHXGSJ             datetime                             NULL,        -- 最后修改时间
    DT_SCSJ               datetime                             NULL,        -- 删除时间
    C_BH_CJR              varchar(300)                         NULL,        -- 创建人主键
    C_BH_ZHXGR            varchar(300)                         NULL,        -- 最后修改人主键
    C_BH_SSDW             varchar(300)                         NULL,        -- 所属单位主键
    C_BH_ST               char(32)                             NULL,        -- 实体主键
constraint PK_YWGY_JLZL primary key( C_BH )
);

 commit; 

