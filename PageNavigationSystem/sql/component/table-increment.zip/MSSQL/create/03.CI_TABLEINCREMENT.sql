use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_ST') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_ST 
end
go 
create  index I_YWGY_STZL_ST on T_YWGY_STZL (C_BH_ST) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_ZHXGSJ') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_ZHXGSJ 
end
go 
create  index I_YWGY_STZL_ZHXGSJ on T_YWGY_STZL (DT_ZHXGSJ) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_SSDW') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_SSDW 
end
go 
create  index I_YWGY_STZL_SSDW on T_YWGY_STZL (C_BH_SSDW) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_CJR') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_CJR 
end
go 
create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_ZHXGR') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_ZHXGR 
end
go 
create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_JLZL') and name='I_YWGY_JLZL_JL') 
begin
  drop index  T_YWGY_JLZL.I_YWGY_JLZL_JL 
end
go 
create  index I_YWGY_JLZL_JL on T_YWGY_JLZL (C_BH_JL) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_JLZL') and name='I_YWGY_JLZL_ZHGXSJ') 
begin
  drop index  T_YWGY_JLZL.I_YWGY_JLZL_ZHGXSJ 
end
go 
create  index I_YWGY_JLZL_ZHGXSJ on T_YWGY_JLZL (DT_ZHXGSJ) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_JLZL') and name='I_YWGY_JLZL_BM') 
begin
  drop index  T_YWGY_JLZL.I_YWGY_JLZL_BM 
end
go 
create  index I_YWGY_JLZL_BM on T_YWGY_JLZL (C_BM) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_JLZL') and name='I_YWGY_JLZL_SSDW') 
begin
  drop index  T_YWGY_JLZL.I_YWGY_JLZL_SSDW 
end
go 
create  index I_YWGY_JLZL_SSDW on T_YWGY_JLZL (C_BH_SSDW) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_JLZL') and name='I_YWGY_JLZL_ST') 
begin
  drop index  T_YWGY_JLZL.I_YWGY_JLZL_ST 
end
go 
create  index I_YWGY_JLZL_ST on T_YWGY_JLZL (C_BH_ST) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_CJR') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_CJR 
end
go 
create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR) 
go


use DB_YWST
go

if exists(select * from sysindexes where id=object_id('T_YWGY_STZL') and name='I_YWGY_STZL_ZHXGR') 
begin
  drop index  T_YWGY_STZL.I_YWGY_STZL_ZHXGR 
end
go 
create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR) 
go


