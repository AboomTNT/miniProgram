-- auto create by SMD

use DB_YWST
go

-------------------------
-- 实体增量表
-------------------------

if exists( select 1 from sysobjects
              where xtype='U' and name= 'T_YWGY_STZL') 
   drop table T_YWGY_STZL 
go 


create table DB_YWST.dbo.T_YWGY_STZL
(
    C_BH                  char(32)                             NOT NULL,    -- 主键
    C_YWLX                varchar(300)                         NULL,        -- 业务类型
    C_BH_ST               char(32)                             NULL,        -- 实体主键
    N_ZHXGFS              integer                              NULL,        -- 最后修改方式
    DT_CJSJ               datetime                             NULL,        -- 创建时间
    DT_ZHXGSJ             datetime                             NULL,        -- 最后修改时间
    DT_SCSJ               datetime                             NULL,        -- 删除时间
    C_BH_CJR              varchar(300)                         NULL,        -- 创建人主键
    C_BH_ZHXGR            varchar(300)                         NULL,        -- 最后修改人主键
    C_BH_SSDW             varchar(300)                         NULL,        -- 所属单位主键
constraint PK_YWGY_STZL primary key( C_BH )
) 
go 

exec sp_addextendedproperty 'MS_Description', '主键', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'C_BH' 
go 

exec sp_addextendedproperty 'MS_Description', '业务类型', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'C_YWLX' 
go 

exec sp_addextendedproperty 'MS_Description', '实体主键', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'C_BH_ST' 
go 

exec sp_addextendedproperty 'MS_Description', '最后修改方式', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'N_ZHXGFS' 
go 

exec sp_addextendedproperty 'MS_Description', '创建时间', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'DT_CJSJ' 
go 

exec sp_addextendedproperty 'MS_Description', '最后修改时间', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'DT_ZHXGSJ' 
go 

exec sp_addextendedproperty 'MS_Description', '删除时间', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'DT_SCSJ' 
go 

exec sp_addextendedproperty 'MS_Description', '创建人主键', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'C_BH_CJR' 
go 

exec sp_addextendedproperty 'MS_Description', '最后修改人主键', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'C_BH_ZHXGR' 
go 

exec sp_addextendedproperty 'MS_Description', '所属单位主键', 'user', 'dbo', 'table', 'T_YWGY_STZL', 'column', 'C_BH_SSDW' 
go 

use DB_YWST
go

-------------------------
-- 数据删除记录
-------------------------

if exists( select 1 from sysobjects
              where xtype='U' and name= 'T_YWGY_JLZL') 
   drop table T_YWGY_JLZL 
go 


create table DB_YWST.dbo.T_YWGY_JLZL
(
    C_BH                  char(32)                             NOT NULL,    -- 主键
    C_BM                  varchar(300)                         NULL,        -- 表名
    C_BH_JL               char(32)                             NULL,        -- 记录主键
    N_ZHXGFS              integer                              NULL,        -- 最后修改方式
    DT_CJSJ               datetime                             NULL,        -- 创建时间
    DT_ZHXGSJ             datetime                             NULL,        -- 最后修改时间
    DT_SCSJ               datetime                             NULL,        -- 删除时间
    C_BH_CJR              varchar(300)                         NULL,        -- 创建人主键
    C_BH_ZHXGR            varchar(300)                         NULL,        -- 最后修改人主键
    C_BH_SSDW             varchar(300)                         NULL,        -- 所属单位主键
    C_BH_ST               char(32)                             NULL,        -- 实体主键
constraint PK_YWGY_JLZL primary key( C_BH )
) 
go 

exec sp_addextendedproperty 'MS_Description', '主键', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BH' 
go 

exec sp_addextendedproperty 'MS_Description', '表名', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BM' 
go 

exec sp_addextendedproperty 'MS_Description', '记录主键', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BH_JL' 
go 

exec sp_addextendedproperty 'MS_Description', '最后修改方式', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'N_ZHXGFS' 
go 

exec sp_addextendedproperty 'MS_Description', '创建时间', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'DT_CJSJ' 
go 

exec sp_addextendedproperty 'MS_Description', '最后修改时间', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'DT_ZHXGSJ' 
go 

exec sp_addextendedproperty 'MS_Description', '删除时间', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'DT_SCSJ' 
go 

exec sp_addextendedproperty 'MS_Description', '创建人主键', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BH_CJR' 
go 

exec sp_addextendedproperty 'MS_Description', '最后修改人主键', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BH_ZHXGR' 
go 

exec sp_addextendedproperty 'MS_Description', '所属单位主键', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BH_SSDW' 
go 

exec sp_addextendedproperty 'MS_Description', '实体主键', 'user', 'dbo', 'table', 'T_YWGY_JLZL', 'column', 'C_BH_ST' 
go 

