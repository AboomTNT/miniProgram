-- auto create by SMD

-------------------------
-- 实体增量表
-------------------------
exec sp_DropObject('T_YWGY_STZL', 'TABLE');
create table T_YWGY_STZL
(
    C_BH                  char(32)                             NOT NULL,    -- 主键
    C_YWLX                varchar2(300)                        NULL,        -- 业务类型
    C_BH_ST               char(32)                             NULL,        -- 实体主键
    N_ZHXGFS              number(10, 0)                        NULL,        -- 最后修改方式
    DT_CJSJ               date                                 NULL,        -- 创建时间
    DT_ZHXGSJ             date                                 NULL,        -- 最后修改时间
    DT_SCSJ               date                                 NULL,        -- 删除时间
    C_BH_CJR              varchar2(300)                        NULL,        -- 创建人主键
    C_BH_ZHXGR            varchar2(300)                        NULL,        -- 最后修改人主键
    C_BH_SSDW             varchar2(300)                        NULL,        -- 所属单位主键
constraint PK_YWGY_STZL primary key( C_BH )
)
logging
TableSpace TBS_DB_YWST;
exec sp_CheckCreateInfo('T_YWGY_STZL', 'TABLE');

-------------------------
-- 数据删除记录
-------------------------
exec sp_DropObject('T_YWGY_JLZL', 'TABLE');
create table T_YWGY_JLZL
(
    C_BH                  char(32)                             NOT NULL,    -- 主键
    C_BM                  varchar2(300)                        NULL,        -- 表名
    C_BH_JL               char(32)                             NULL,        -- 记录主键
    N_ZHXGFS              number(10, 0)                        NULL,        -- 最后修改方式
    DT_CJSJ               date                                 NULL,        -- 创建时间
    DT_ZHXGSJ             date                                 NULL,        -- 最后修改时间
    DT_SCSJ               date                                 NULL,        -- 删除时间
    C_BH_CJR              varchar2(300)                        NULL,        -- 创建人主键
    C_BH_ZHXGR            varchar2(300)                        NULL,        -- 最后修改人主键
    C_BH_SSDW             varchar2(300)                        NULL,        -- 所属单位主键
    C_BH_ST               char(32)                             NULL,        -- 实体主键
constraint PK_YWGY_JLZL primary key( C_BH )
)
logging
TableSpace TBS_DB_YWST;
exec sp_CheckCreateInfo('T_YWGY_JLZL', 'TABLE');

