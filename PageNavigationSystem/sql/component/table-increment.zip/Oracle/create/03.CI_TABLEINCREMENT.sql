exec sp_DropObject('I_YWGY_STZL_ST', 'INDEX');
create  index I_YWGY_STZL_ST on T_YWGY_STZL (C_BH_ST);

exec sp_DropObject('I_YWGY_STZL_ZHXGSJ', 'INDEX');
create  index I_YWGY_STZL_ZHXGSJ on T_YWGY_STZL (DT_ZHXGSJ);

exec sp_DropObject('I_YWGY_STZL_SSDW', 'INDEX');
create  index I_YWGY_STZL_SSDW on T_YWGY_STZL (C_BH_SSDW);

exec sp_DropObject('I_YWGY_STZL_CJR', 'INDEX');
create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR);

exec sp_DropObject('I_YWGY_STZL_ZHXGR', 'INDEX');
create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR);

exec sp_DropObject('I_YWGY_JLZL_JL', 'INDEX');
create  index I_YWGY_JLZL_JL on T_YWGY_JLZL (C_BH_JL);

exec sp_DropObject('I_YWGY_JLZL_ZHGXSJ', 'INDEX');
create  index I_YWGY_JLZL_ZHGXSJ on T_YWGY_JLZL (DT_ZHXGSJ);

exec sp_DropObject('I_YWGY_JLZL_BM', 'INDEX');
create  index I_YWGY_JLZL_BM on T_YWGY_JLZL (C_BM);

exec sp_DropObject('I_YWGY_JLZL_SSDW', 'INDEX');
create  index I_YWGY_JLZL_SSDW on T_YWGY_JLZL (C_BH_SSDW);

exec sp_DropObject('I_YWGY_JLZL_ST', 'INDEX');
create  index I_YWGY_JLZL_ST on T_YWGY_JLZL (C_BH_ST);

exec sp_DropObject('I_YWGY_STZL_CJR', 'INDEX');
create  index I_YWGY_STZL_CJR on T_YWGY_STZL (C_BH_CJR);

exec sp_DropObject('I_YWGY_STZL_ZHXGR', 'INDEX');
create  index I_YWGY_STZL_ZHXGR on T_YWGY_STZL (C_BH_ZHXGR);

