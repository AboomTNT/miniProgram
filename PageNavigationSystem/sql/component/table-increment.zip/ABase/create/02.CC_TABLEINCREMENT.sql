-- auto create by SMD

set client_encoding = UTF8;
set search_path to DB_YWST;
commit;

comment on table  T_YWGY_STZL                                  is '实体增量表';
comment on column T_YWGY_STZL.C_BH                             is '主键';
comment on column T_YWGY_STZL.C_YWLX                             is '业务类型';
comment on column T_YWGY_STZL.C_BH_ST                             is '实体主键';
comment on column T_YWGY_STZL.N_ZHXGFS                             is '最后修改方式';
comment on column T_YWGY_STZL.DT_CJSJ                             is '创建时间';
comment on column T_YWGY_STZL.DT_ZHXGSJ                             is '最后修改时间';
comment on column T_YWGY_STZL.DT_SCSJ                             is '删除时间';
comment on column T_YWGY_STZL.C_BH_CJR                             is '创建人主键';
comment on column T_YWGY_STZL.C_BH_ZHXGR                             is '最后修改人主键';
comment on column T_YWGY_STZL.C_BH_SSDW                             is '所属单位主键';

set client_encoding = UTF8;
set search_path to DB_YWST;
commit;

comment on table  T_YWGY_JLZL                                  is '数据删除记录';
comment on column T_YWGY_JLZL.C_BH                             is '主键';
comment on column T_YWGY_JLZL.C_BM                             is '表名';
comment on column T_YWGY_JLZL.C_BH_JL                             is '记录主键';
comment on column T_YWGY_JLZL.N_ZHXGFS                             is '最后修改方式';
comment on column T_YWGY_JLZL.DT_CJSJ                             is '创建时间';
comment on column T_YWGY_JLZL.DT_ZHXGSJ                             is '最后修改时间';
comment on column T_YWGY_JLZL.DT_SCSJ                             is '删除时间';
comment on column T_YWGY_JLZL.C_BH_CJR                             is '创建人主键';
comment on column T_YWGY_JLZL.C_BH_ZHXGR                             is '最后修改人主键';
comment on column T_YWGY_JLZL.C_BH_SSDW                             is '所属单位主键';
comment on column T_YWGY_JLZL.C_BH_ST                             is '实体主键';

